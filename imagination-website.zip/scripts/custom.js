<!DOCTYPE html>
<html dir="ltr" lang="en-US" prefix="og: https://ogp.me/ns#">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="https://wintr.gr/xmlrpc.php" />
	<title>Page not found &#8211; Wintr</title>

		<!-- All in One SEO 4.9.3 - aioseo.com -->
	<meta name="robots" content="noindex" />
	<meta name="generator" content="All in One SEO (AIOSEO) 4.9.3" />
		<script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"BreadcrumbList","@id":"https:\/\/wintr.gr\/wp-content\/themes\/aixor\/assets\/js\/custom.js\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/wintr.gr#listItem","position":1,"name":"Home","item":"https:\/\/wintr.gr","nextItem":{"@type":"ListItem","@id":"#listItem","name":"404 - Page Not Found"}}]},{"@type":"Organization","@id":"https:\/\/wintr.gr\/#organization","name":"Wintr","description":"Brutally Honest","url":"https:\/\/wintr.gr\/","logo":{"@type":"ImageObject","url":"https:\/\/wintr.gr\/wp-content\/uploads\/2026\/02\/wint-white.png","@id":"https:\/\/wintr.gr\/wp-content\/themes\/aixor\/assets\/js\/custom.js\/#organizationLogo","width":1053,"height":279},"image":{"@id":"https:\/\/wintr.gr\/wp-content\/themes\/aixor\/assets\/js\/custom.js\/#organizationLogo"}},{"@type":"WebPage","@id":"https:\/\/wintr.gr\/wp-content\/themes\/aixor\/assets\/js\/custom.js\/#webpage","url":"https:\/\/wintr.gr\/wp-content\/themes\/aixor\/assets\/js\/custom.js\/","inLanguage":"en-US","isPartOf":{"@id":"https:\/\/wintr.gr\/#website"},"breadcrumb":{"@id":"https:\/\/wintr.gr\/wp-content\/themes\/aixor\/assets\/js\/custom.js\/#breadcrumblist"}},{"@type":"WebSite","@id":"https:\/\/wintr.gr\/#website","url":"https:\/\/wintr.gr\/","name":"Wintr","description":"Brutally Honest","inLanguage":"en-US","publisher":{"@id":"https:\/\/wintr.gr\/#organization"}}]}
		</script>
		<!-- All in One SEO -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin />
<link rel="alternate" type="application/rss+xml" title="Wintr &raquo; Feed" href="https://wintr.gr/feed/" />
<link rel="alternate" type="application/rss+xml" title="Wintr &raquo; Comments Feed" href="https://wintr.gr/comments/feed/" />
		<!-- This site uses the Google Analytics by MonsterInsights plugin v11.1.3 - Using Analytics tracking - https://www.monsterinsights.com/ -->
		<!-- Note: MonsterInsights is not currently configured on this site. The site owner needs to authenticate with Google Analytics in the MonsterInsights settings panel. -->
					<!-- No tracking code set -->
				<!-- / Google Analytics by MonsterInsights -->
		<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>

<link rel='stylesheet' id='hfe-widgets-style-css' href='https://wintr.gr/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.8.3' media='all' />
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://wintr.gr/wp-includes/css/dist/block-library/style.min.css?ver=7.1.4' media='all' />
<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<link rel='stylesheet' id='aioseo/css/src/vue/standalone/blocks/table-of-contents/global.scss-css' href='https://wintr.gr/wp-content/plugins/all-in-one-seo-pack/dist/Lite/assets/css/table-of-contents/global.e90f6d47.css?ver=4.9.3' media='all' />
<style id="safe-svg-svg-icon-style-inline-css">
.safe-svg-cover{text-align:center}.safe-svg-cover .safe-svg-inside{display:inline-block;max-width:100%}.safe-svg-cover svg{fill:currentColor;height:100%;max-height:100%;max-width:100%;width:100%}

/*# sourceURL=https://wintr.gr/wp-content/plugins/safe-svg/dist/safe-svg-block-frontend.css */
</style>
<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}.wp-block-button{--wp--preset--dimension--25: 25%;--wp--preset--dimension--50: 50%;--wp--preset--dimension--75: 75%;--wp--preset--dimension--100: 100%;}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:root :where(.wp-block-icon svg){width: 24px;}
:where(.wp-block-gallery.is-layout-flex){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}:where(.wp-block-gallery.is-layout-grid){gap: var( --wp--style--gallery-gap-default, var( --gallery-block--gutter-size, var( --wp--style--block-gap, 0.5em ) ) );}
:where(.wp-block-latest-posts.is-layout-flex){gap: 1.25em;}:where(.wp-block-latest-posts.is-layout-grid){gap: 1.25em;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
/*# sourceURL=global-styles-inline-css */
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://wintr.gr/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.5' media='all' />
<link rel='stylesheet' id='hfe-style-css' href='https://wintr.gr/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.8.3' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.35.3' media='all' />
<link rel='stylesheet' id='elementor-post-8-css' href='https://wintr.gr/wp-content/uploads/elementor/css/post-8.css?ver=1787192720' media='all' />
<link rel='stylesheet' id='elementor-post-1652-css' href='https://wintr.gr/wp-content/uploads/elementor/css/post-1652.css?ver=1787192720' media='all' />
<link rel='stylesheet' id='elementor-post-1066-css' href='https://wintr.gr/wp-content/uploads/elementor/css/post-1066.css?ver=1787192720' media='all' />
<link rel='stylesheet' id='line-awesome-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/line-awesome.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='iconoir-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/iconoir.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='fontawesome-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/all.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/bootstrap.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='animate-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/animate.min.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='aos-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/aos.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='aixor-main-style-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/style.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='aixor-style-css' href='https://wintr.gr/wp-content/themes/aixor/style.css?ver=1.0.0' media='all' />
<link rel='stylesheet' id='aixor-unit-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/aixor-unit-test.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='aixor-fonts-css' href='https://fonts.googleapis.com/css2?family=Arapey:ital@0;1&#038;family=Urbanist:ital,wght@0,100..900;1,100..900&#038;display=swap&#038;ver=1.0.0' media='all' />
<link rel='stylesheet' id='aixor-responsive-css' href='https://wintr.gr/wp-content/themes/aixor/assets/css/responsive.css?ver=7.1.4' media='all' />
<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' media='all' />
<link rel='stylesheet' id='hfe-icons-list-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' media='all' />
<link rel='stylesheet' id='hfe-social-icons-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://wintr.gr/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' media='all' />
<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Arapey%7CUrbanist:400italic&#038;display=swap&#038;ver=1770827468" /><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arapey%7CUrbanist:400italic&#038;display=swap&#038;ver=1770827468" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arapey%7CUrbanist:400italic&#038;display=swap&#038;ver=1770827468" /></noscript><link rel='stylesheet' id='elementor-gf-roboto-css' href='https://fonts.googleapis.com/css?family=Roboto:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic&#038;display=swap' media='all' />
<link rel='stylesheet' id='elementor-gf-robotoslab-css' href='https://fonts.googleapis.com/css?family=Roboto+Slab:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic&#038;display=swap' media='all' />
<script id="jquery-core-js" src="https://wintr.gr/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="https://wintr.gr/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>
<script id="jquery-js-after">
!function($){"use strict";$(document).ready(function(){$(this).scrollTop()>100&&$(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"),$(window).scroll(function(){$(this).scrollTop()<100?$(".hfe-scroll-to-top-wrap").fadeOut(300):$(".hfe-scroll-to-top-wrap").fadeIn(300)}),$(".hfe-scroll-to-top-wrap").on("click",function(){$("html, body").animate({scrollTop:0},300);return!1})})}(jQuery);
!function($){'use strict';$(document).ready(function(){var bar=$('.hfe-reading-progress-bar');if(!bar.length)return;$(window).on('scroll',function(){var s=$(window).scrollTop(),d=$(document).height()-$(window).height(),p=d? s/d*100:0;bar.css('width',p+'%')});});}(jQuery);
//# sourceURL=jquery-js-after
</script>
<link rel="https://api.w.org/" href="https://wintr.gr/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://wintr.gr/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 7.1.4" />
<meta name="generator" content="Redux 4.5.10" />
<style>

:root {

    --primary: #FFFFFF;

    --secondary: #999999;
    
    --tertiary: #666666;

    
}
body{
        background-color: #000000;
    }

</style>

<meta name="generator" content="Elementor 3.35.3; features: e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://wintr.gr/wp-content/uploads/2026/02/cropped-wint-32x32.png" sizes="32x32" />
<link rel="icon" href="https://wintr.gr/wp-content/uploads/2026/02/cropped-wint-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://wintr.gr/wp-content/uploads/2026/02/cropped-wint-180x180.png" />
<meta name="msapplication-TileImage" content="https://wintr.gr/wp-content/uploads/2026/02/cropped-wint-270x270.png" />
<style id="wp-custom-css">
/* .feature-more-btn-wrap {
	display: none;
} */
</style>
<style id="aixor_options-dynamic-css" title="dynamic-css" class="redux-options-output">.error-hero-sec .hero-bottom h2{font-family:Arapey;font-weight:normal;font-style:italic;}.error-hero-sec .hero-bottom h2 span{font-family:Urbanist;font-weight:normal;font-style:normal;}.error-hero-sec .hero-bottom p{font-family:Urbanist;font-weight:400;font-style:italic;}.theme-btn{font-family:Urbanist;font-weight:normal;font-style:normal;}.theme-btn:hover{font-family:Urbanist;font-weight:normal;font-style:normal;}</style></head>

<body class="error404 wp-custom-logo wp-theme-aixor ehf-header ehf-footer ehf-template-aixor ehf-stylesheet-aixor elementor-default elementor-kit-8">
<div id="page" class="hfeed site">

		<header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">
			<p class="main-title bhf-hidden" itemprop="headline"><a href="https://wintr.gr" title="Wintr" rel="home">Wintr</a></p>
					<div data-elementor-type="wp-post" data-elementor-id="1652" class="elementor elementor-1652">
				<div class="elementor-element elementor-element-6ea909b0 e-con-full e-flex e-con e-parent" data-id="6ea909b0" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-8c455fc elementor-widget elementor-widget-aixor-home-headerv1" data-id="8c455fc" data-element_type="widget" data-e-type="widget" data-widget_type="aixor-home-headerv1.default">
				<div class="elementor-widget-container">
					        <!-- ===== Header Sidebar Start ===== -->
                <!-- ===== Header Sidebar End ===== -->

        <!-- ===== Menu Start ===== -->
        <header class="header-menu-wrap">
            <div class="custom-container">
                <div class="custom-row">
                    <a                     href="http://wintr.gr" class="logo">
                        <img src="https://wintr.gr/wp-content/uploads/2026/02/wint-white.png" alt="">
                    </a>
                                        <nav class="navbar">
                        <ul class="menu">
                                                                                    <li class="dropdown-menu-item">
                                    <a href="https://wintr.gr">
                                        Home                                        <span></span>
                                                                            </a>
                                                                </li>
                                                        <li class="dropdown-menu-item">
                                    <a href="http://wintr.gr/about-us/">
                                        About Us                                        <span></span>
                                                                            </a>
                                                                </li>
                                                        <li class="dropdown-menu-item">
                                    <a href="http://wintr.gr/contact/">
                                        Contact                                        <span></span>
                                                                            </a>
                                                                </li>
                                                                                </ul>
                    </nav>
                                        <div class="header-right-info">
                        <a                         class="with-border" href="">
                                                    </a>
                        
                        <a                         href="mailto:email@example.com">
                           <i class="iconoir-mail-out"></i>
                        </a>
                    </div>
                </div>
            </div>
        </header>
        <!-- ===== Menu End ===== -->
        				</div>
				</div>
				</div>
				</div>
				</header>

	<!doctype html>
<html dir="ltr" lang="en-US" prefix="og: https://ogp.me/ns#">
<head>
    <!-- ===== Meta ===== -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- ===== Stylesheet ===== -->
    <!-- CSS Start -->
        <style>
            @media (max-width: 699px) {
                #magic-cursor {
                                    }
            }
        </style>
    <!-- CSS End -->
    </head>

<body class="error404 wp-custom-logo wp-theme-aixor ehf-header ehf-footer ehf-template-aixor ehf-stylesheet-aixor elementor-default elementor-kit-8">

<!-- ===== Pre Loader Start ===== -->
<div class="preloader-wrap">
    <video src="./assets/video/hero-video.mp4" loop muted autoplay="" playsinline=""></video>
    <img src="https://wintr.gr/wp-content/uploads/2026/02/wint-white.png" alt="Logo">
</div>
<!-- ===== Pre Loader End ===== -->

<!-- ===== Magic Cursor Start ===== -->
<div id="magic-cursor">
    <div id="ball"></div>
</div>
 <!-- ===== Magic Cursor End ===== -->

<!-- ===== Main Start ===== -->
<main class="aixor-main error-page-area">
    <!-- ===== Header Sidebar Start ===== -->
    <!-- ===== Header Sidebar End ===== -->


<!-- Start 404
============================================= -->

<!-- ===== Hero Start ===== -->
<div class="hero-sec error-hero-sec">
    <div class="custom-container">
        <div class="hero-inner">
            <!-- Shape Section -->
                        <img class="hero-shape" src="https://wintr.gr/wp-content/themes/aixor/assets/images/contact.png" alt="shape">
                        <!-- Hero Bottom Section -->
            <div class="hero-bottom error-box">
                <div class="left">
                    <h2><span>Oops!</span> Page Not<br>Found (404)</h2>
                </div>
                <p>
                    <span class='required'>*</span>We couldn't find the page you're looking for. This could be because the page has been moved or<br>deleted, you might have mistyped the URL, or the link you followed could be outdated.                </p>
                <!-- Button Section -->
                                                <a href="https://wpriverthemes.com/aixor/contact/" class="theme-btn">
                    Back To Home                    <img src="https://wintr.gr/wp-content/themes/aixor/assets/images/btn-arrow.svg" alt="icon">
                </a>
                                            </div>
        </div>
    </div>
</div>
        <!-- ===== Hero End ===== -->
<!-- End 404 -->

		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="1066" class="elementor elementor-1066">
				<div class="elementor-element elementor-element-62cb3a52 e-con-full e-flex e-con e-parent" data-id="62cb3a52" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-515eb8fa elementor-widget elementor-widget-aixor-home-footer" data-id="515eb8fa" data-element_type="widget" data-e-type="widget" data-widget_type="aixor-home-footer.default">
				<div class="elementor-widget-container">
					        <!-- ===== Footer Start ===== -->
    <footer class="footer-area">

        <div class="footer-top">
            <div class="row">

                <div class="col-md-3">
                    <div class="footer-widget footer-link">
                        <div class="footer-widget-top">
                            <h4>COMPANY</h4>
                            <ul>
                                                                <li><a                                 class="with-border" href="">
                                <img src="https://wintr.gr/wp-content/uploads/2024/09/btn-arrow-1.svg" alt="">                             About Us</a>
                                </li>
                                                                <li><a                                 class="with-border" href="">
                                <img src="https://wintr.gr/wp-content/uploads/2024/09/btn-arrow-1.svg" alt="">                             CONTACT</a>
                                </li>
                                                            </ul>
                        </div>
                        <div class="copyright">
                            ©  2026 ALL RIGHTS RESERVED                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-widget footer-link">
                        <div class="footer-contact-infos">
                            <div class="footer-widget-top">
                                <h4>REACH OUT TO US</h4>
                                <div class="links">
                                                                        <div class="split-text-anim">
                                        <a data-aos="slide-up" href="tel:+840123456789" class="with-border">(+84) 0123456789</a>
                                    </div>
                                                                        <div class="split-text-anim">
                                        <a data-aos="slide-up" href="http://MindBlowingArt2692@gmail.com" class="with-border">MindBlowingArt2692@gmail.com</a>
                                    </div>
                                                                    </div>
                            </div>
                                                        <a                             href="" class="theme-btn">
                                Let&#039;s Connect 
                                <img src="https://wintr.gr/wp-content/uploads/2024/09/btn-arrow-1.svg" alt="">                            </a>
                                                    </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-widget footer-link">
                        <div class="footer-widget-top">
                            <h4>Social</h4>
                            <ul>
                                                                <li><a  target="_blank"                                 class="with-border" href="https://www.instagram.com/">
                                <img src="https://wintr.gr/wp-content/uploads/2024/09/btn-arrow-1.svg" alt="">                                Instagram</a>
                                </li>
                                                                <li><a  target="_blank"                                 class="with-border" href="https://www.dribbble.com/">
                                <img src="https://wintr.gr/wp-content/uploads/2024/09/btn-arrow-1.svg" alt="">                                LinkedIn</a>
                                </li>
                                                            </ul>
                        </div>
                        <div class="copyright">
                            BASED IN LONDON, UK                        </div>
                    </div>
                </div>
            </div>
        </div>
	
		        <div class="footer-bottom">
            <div class="split-text-anim">
                <img data-aos="slide-up" src="https://wintr.gr/wp-content/uploads/2026/02/wint-white.png" alt="">
            </div>
        </div>
		
    </footer>
    <!-- ===== Footer End ===== -->
        				</div>
				</div>
				</div>
				</div>
		</div>		</footer>
	</div><!-- #page -->
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/aixor/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script id="wp-hooks-js" src="https://wintr.gr/wp-includes/js/dist/hooks.min.js?ver=f0f188028580e8dc1255"></script>
<script id="wp-i18n-js" src="https://wintr.gr/wp-includes/js/dist/i18n.min.js?ver=1dfe7db3940c23ea9216"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="swv-js" src="https://wintr.gr/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.5"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/wintr.gr\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
//# sourceURL=contact-form-7-js-before
</script>
<script id="contact-form-7-js" src="https://wintr.gr/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.5"></script>
<script id="aixor-navigation-js" src="https://wintr.gr/wp-content/themes/aixor/js/navigation.js?ver=1.0.0"></script>
<script id="bootstrap-bundle-min-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/bootstrap.bundle.min.js?ver=7.1.4"></script>
<script id="lib-gsap-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/gsap.min.js?ver=3.12.5"></script>
<script id="lib-ScrollTrigger-min-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/ScrollTrigger.min.js?ver=3.12.5"></script>
<script id="split-type-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/split-type.min.js?ver=0.3.4"></script>
<script id="lib-aos-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/aos.js?ver=7.1.4"></script>
<script id="jarallax-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/jarallax.js?ver=7.1.4"></script>
<script id="jarallax-element-min-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/jarallax-element.min.js?ver=7.1.4"></script>
<script id="aixor-main-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/main.js?ver=1794858524"></script>
<script id="custom-script-js-extra">
var themeData = {"imgUrl":"https://wintr.gr/wp-content/themes/aixor/assets/images/btn-arrow.svg"};
//# sourceURL=custom-script-js-extra
</script>
<script id="custom-script-js" src="https://wintr.gr/wp-content/themes/aixor/assets/js/custom.js"></script>
<script id="elementor-webpack-runtime-js" src="https://wintr.gr/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.35.3"></script>
<script id="elementor-frontend-modules-js" src="https://wintr.gr/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.35.3"></script>
<script id="jquery-ui-core-js-before">
jQuery.uiBackCompat = true;
//# sourceURL=jquery-ui-core-js-before
</script>
<script id="jquery-ui-core-js" src="https://wintr.gr/wp-includes/js/jquery/ui/core.min.js?ver=1.14.2"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"3.35.3","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"container":true,"e_optimized_markup":true,"e_pro_free_trial_popup":true,"nested-elements":true,"home_screen":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"cloud-library":true,"e_opt_in_v4_page":true,"e_components":true,"e_interactions":true,"e_editor_one":true,"import-export-customization":true},"urls":{"assets":"https:\/\/wintr.gr\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/wintr.gr\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/wintr.gr\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"a589de6940"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; Wintr","excerpt":""}};
//# sourceURL=elementor-frontend-js-before
</script>
<script id="elementor-frontend-js" src="https://wintr.gr/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.35.3"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://wintr.gr/wp-includes/js/wp-emoji-release.min.js?ver=7.1.4"}}
</script>
<script type="module">
/*! This file is auto-generated */
var e="script#wp-emoji-settings",t=document.querySelector(e);if(!(t instanceof HTMLScriptElement))throw new Error("Element missing: "+e);const r=JSON.parse(t.text),s=(window._wpemojiSettings=r,"wpEmojiSettingsSupports"),o=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(s,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const r=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===r[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,r){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!r(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,r){let a;const s=(a="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),o=(s.textBaseline="top",s.font="600 32px Arial",{});return e.forEach(e=>{o[e]=t(s,e,n,r)}),o}function a(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}r.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(s));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(o),u.toString(),c.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"});const a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=e=>{i(n=e.data),a.terminate(),t(n)})}catch(e){}i(n=f(o,u,c,p))}t(n)}).then(e=>{for(const n in e)r.supports[n]=e[n],r.supports.everything=r.supports.everything&&r.supports[n],"flag"!==n&&(r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&r.supports[n]);var t;r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&!r.supports.flag,r.supports.everything||((t=r.source||{}).concatemoji?a(t.concatemoji):t.wpemoji&&t.twemoji&&(a(t.twemoji),a(t.wpemoji)))});
//# sourceURL=https://wintr.gr/wp-includes/js/wp-emoji-loader.min.js
</script>
</body>
</html> 


<!-- Page supported by LiteSpeed Cache 7.7 on 2026-11-16 19:48:44 -->